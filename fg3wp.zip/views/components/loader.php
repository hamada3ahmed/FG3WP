<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<div class="lp-loader-full">
    <div class="lp-spinner">

    </div>
</div>
