<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<div class="lp-loader-module">
    <div class="lp-spinner">

    </div>
</div>