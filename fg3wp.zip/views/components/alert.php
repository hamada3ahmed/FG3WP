<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<div class="lp-alert hidden">
    <button type="button" class="alert-close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <div class="lp-message">
        
    </div>
    <div class="lp-link">
        <a href="" target="_blank"></a>
    </div>
</div>