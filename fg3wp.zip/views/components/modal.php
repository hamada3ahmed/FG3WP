<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<div class="lp-modal">
    <div class="modal-dlg">
        <div class="modal-cnt">
            <div class="modal-head">
                <h5 class="modal-ttl"></h5>
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="إغلاق">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <p></p>
            </div>
            <img src="<?php echo esc_url(plugins_url('../assets/images/validFrame.gif', dirname(__FILE__))); ?>" alt="gif" class="inst-gif">

            <div class="modal-footer">
                <button type="button" class="lp-btn large blue btn-close" data-dismiss="modal">إلغاء</button>
                <button type="button" id="btn-confirm" class="lp-btn large orange">تأكيد</button>
            </div>
        </div>
    </div>
</div>

<div class="lp-modal-images">
    <div class="modal-dlg">
        <div class="modal-cnt">
            <div class="modal-head">
                <h5 class="modal-ttl"></h5>
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="إغلاق">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="lp-btn large blue btn-close" data-dismiss="modal">إغلاق</button>
            </div>
        </div>
    </div>
</div>

<div class="lp-modal-instructions x-large">
    <div class="modal-dlg">
        <div class="modal-cnt">
            <div class="modal-head">
                <h5 class="modal-ttl">اتبع هذه الخطوات الأربع لإعداد تصاميم Figma للتحويل</h5>
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="إغلاق">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="inst-steps">
                    <div class="lp-box">
                        <div class="row">
                            <div class="col-md-6">
                                
                                <h3>قم بتكوين التصميم الخاص بك مع  AUTO layout</h3>
                                <p>للحصول على أفضل النتائج، نوصي بتكوين جميع الأقسام والحاويات والأعمدة في التصميم الخاص بك باستخدام  AUTO layout  في  Figma. <br><br> ستُحوّل جميع الطبقات التي لم يتم  تكوينها باستخدام  AUTO layout  ،  لكنّك  ستحتاج  إلى  تعيين  التخطيط  يدويًا  في  محرر  صفحة  WordPress. </p>
                            </div>
                        
                            <div class="col-md-6">
                                <img src="<?php echo plugins_url('../assets/images/instructions-1.png', dirname(__FILE__)); ?>" width="100%">

                            </div>
                        </div>
                        <div class="text-right counter">
                            <p>1/4</p>
                        </div>
                    </div>
                    <div class="lp-box">
                        <div class="row">
                            <div class="col-md-6">
                                
                                <h3>أعد تسمية طبقات المجموعة التي تريد معالجتها كصورة واحدة</h3>
                                <p>لِتراكيب العناصر التي تريد استيرادها كصورة واحدة،  قم بِتجميعها  وِضع  اسم  المجموعة  "isImage".  يساعد  هذا  WPLandings  على  استيرادها  بدقة. <br><br>في  المثال  لدينا  هاتف  جوال  مُركّب  من  عدة  طبقات  نريد  استخدامها  كصورة  واحدة.  لِتحقيق  ذلك،  قم  بِتجميع  هذه  العناصر  معًا  وِضع  اسم  المجموعة  "isImage"  لِضمان  استيراد  التراكيب  كاملة  كصورة  واحدة. </p>
                            </div>
                        
                            <div class="col-md-6">
                                <img src="<?php echo plugins_url('../assets/images/instructions-2.png', dirname(__FILE__)); ?>" width="100%">

                            </div>
                        </div>
                        <div class="text-right counter">
                            <p>2/4</p>
                        </div>
                    </div>
                    <div class="lp-box">
                        <div class="row">
                            <div class="col-md-6">
                                
                                <h3>استبعد من تصميمك  قوائم  التنقل  في  الرأس  وِالقدم  </h3>
                                <p>قم  بِإخفاء  أو  حذف  قوائم  التنقل  في  الرأس  أو  القدم  من  تصميم  Figma  الخاص  بك.  بينما  لا  يقوم  WPLandings  بِاستيراد  قوائم  التنقل  الفعّالة،  يمكنك  دمج  قوائم  التنقل  الموجودة  من  مُوضوع  WordPress  الخاص  بك.  </p>
                            </div>
                        
                            <div class="col-md-6">
                                <img src="<?php echo plugins_url('../assets/images/instructions-3.png', dirname(__FILE__)); ?>" width="100%">

                            </div>
                        </div>
                        <div class="text-right counter">
                            <p>3/4</p>
                        </div>
                    </div>
                    <div class="lp-box">
                        <div class="row">
                            <div class="col-md-6">
                                
                                <h3>قم  بتثبيت  خطوط  خاصة  في  موضوعك</h3>
                                <p>تأكد  من  أن  جميع  الخطوط  المُستخدمة  في  التصميم  مُثبّتة  في  مُوضوعك.</p>
                            </div>
                            <div class="col-md-6">
                                
                                <h3>العناصر  التفاعلية</h3>
                                <p>لا  يقوم  WPLandings  بِإنشاء  عناصر  تفاعلية  مثل  النماذج  أو  العروض  التدويرية  أو  العلامات  التبويب  أو  الأنظمة  المُتوافقة.  لِهذه  الميزات،  استبدل  الكود  المُنشأ  بِرموز  قصيرة  أو  كتل  من  إضافات  أطراف  ثالثة  متخصصة.</p>
                            </div>
                        </div>
                        <div class="text-right counter">
                            <p>4/4</p>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="lp-btn large white outline btn-close" data-dismiss="modal">تخطي</button>
                <button type="button" class="lp-btn large blue btn-next" data-dismiss="modal">التالي</button>
                <button type="button" class="lp-btn large orange btn-confirm" data-dismiss="modal">إنهاء</button>
            </div>
        </div>
    </div>
</div>