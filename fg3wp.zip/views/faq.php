<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

$options = get_option('illiant_wplandings');
$openaiKey = isset($options['openai']) ? $options['openai'] : '';
$figmaKey = isset($options['figma']) ? $options['figma'] : '';
?>
<?php
    $optionsLp = get_option('illiant_landings_lp');
    $import = isset($optionsLp['import']) ? $optionsLp['import'] : 0;
    $convert = isset($optionsLp['convert']) ? $optionsLp['convert'] : 0;
    $edit = isset($optionsLp['edit']) ? $optionsLp['edit'] : 0;
?>
<div class="wrap illiant-documentation wp-landings">

	<div class="headline-wrapper">
		<h1><img src="<?php echo plugins_url('/assets/images/FG3WP.png', dirname(__FILE__)); ?>" alt="FG3WP" width="140"> |  وثائق</h1>
	</div>
	<div class="lp-box lp-docs">
		<div class="lp-docs-nav">
			<ul>
				<li>
					<a href="#d-1">البدء</a>
					<ul>
						<li><a href="#d-1-1">الحصول على  رمز  وصول  Figma</a></li>
					</ul>
				</li>
				<li>
					<a href="#d-2">كيفية  إعداد  تصميم  Figma</a>
					<ul>
						<li><a href="#d-2-2">دليل  إعداد  التصميم</a></li>
					</ul>
				</li>
			</ul>
		</div>
		<div class="lp-docs-content">
			<h1 id="d-1">البدء</h1>
			
			<h2 id="d-1-1">الحصول على رمز  وصول  Figma</h2>
			<p>رمز  وصول  Figma  هو  عبارة  عن  "كلمة  سرّ"  آمنة  تُمكّن  البرامج  من  الوصول  إلى  تصاميمك  وِبياناتك  في  Figma. <br><br>

للحصول  على  رمزك:</p>
			<p>1. افتح  تطبيق  Figma  على  سطح  المكتب  أو  موقع  الإنترنت  وِادخل  إلى  إعدادات  حسابك.  ابحث  عن  قسم  <strong>رموز  الوصول  الشخصية</strong>.</p>
			<img src="<?php echo plugins_url('/assets/images/figma-settings.png', dirname(__FILE__)); ?>" width="200">
			<p>2.  اختر  <strong>إنشاء  رمز  جديد</strong>،  وِأعطِه  اسمًا،  وِانسخ  الرمز.  يُمكن  هذا  WPLandings  من  استيراد  تصاميمك  في  Figma.  </p>
			<img src="<?php echo plugins_url('/assets/images/figma-token.png', dirname(__FILE__)); ?>" width="400">
			<p>3.  تأكد  من  أن  حساب  Figma  الذي  يحتوي  على  رمز  الوصول  له  أذونات  العرض  أو  التحرير  للِملف،  وِخاصة  إذا  كان  الِملف  خاصًا.</p>
			
			<hr></hr>


			<h1 id="d-2">كيفية  إعداد  تصميم  Figma</h1>
			<h2 id="d-2-2">دليل  إعداد  التصميم</h2>
			<p>1. <strong>قم بتكوين التصميم الخاص بك مع  AUTO layout</strong>: For the best results, we recommend configuring all sections, containers and columns of your design with AUTO layout in Figma. <br><br> All layers that are not configured with AUTO layout will still be converted, but you will need to manually set the layout in the WordPress Page editor.</p>
			
			<img src="<?php echo plugins_url('/assets/images/instructions-1.png', dirname(__FILE__)); ?>" width="100%">

			<p>2. <strong>أعد تسمية طبقات المجموعة التي تريد معالجتها كصورة واحدة</strong>: For compositions of elements you wish to import as a single image, group them and label the group "isImage." This helps WPLandings to import them accurately.<br><br>In the example we have a cellphone composed of multiple layers that we want to use a single image. To achieve this, group these elements together and label the group as "isImage" to ensure the entire composition is imported as a single image.</p>

			<img src="<?php echo plugins_url('/assets/images/instructions-2.png', dirname(__FILE__)); ?>" width="100%">
		
			<p>3. <strong>استبعد من تصميمك  قوائم  التنقل  في  الرأس  وِالقدم  </strong>: Hide or delete headers or footers navs from your Figma design. While WPLandings does not import functional nav menus, you can integrate existing ones from your WordPress theme.</p>

			<img src="<?php echo plugins_url('/assets/images/instructions-3.png', dirname(__FILE__)); ?>" width="100%">

			<p>4. <strong>قم  بتثبيت  خطوط  خاصة  في  موضوعك</strong>: Please ensure that all fonts used in your design are installed in your theme.</p>

			<p>5. <strong>العناصر  التفاعلية</strong>: WPLandings does not create interactive elements like forms, carousels, tabs, or accordions. For these features, replace the generated code with shortcodes or blocks from specialized third-party plugins.</p>

			<h2>هل  تحتاج  إلى  المساعدة؟</h2>
			<p>If you encounter any issues during the conversion process or have questions about preparing your design, we're here to support you. For assistance, simply fill out the <a href="#">support form</a>.</p>

		</div>
		<div class="clear"></div>

	</div>
</div>