<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

$plan = fg3_fs()->get_plan();
$license = fg3_fs()->_get_license();

// Initialize variables
$licenseId = null;
$created = null;
$updated = null;
$expiration = null;
$planName = "مجاني"; 

// Check if plan exists and assign plan name
if ($plan !== null && is_object($plan) && isset($plan->name)) {
    $planName = $plan->name;
}

// Only proceed if $license is an object
if (is_object($license)) {
    if (isset($license->id)) {
        $licenseId = $license->id;
    }
    if (isset($license->created)) {
        $created = $license->created;
    }
    if (isset($license->expiration)) {
        $expiration = $license->expiration;
    }
}


?>

<div class="wrap illiant-page wp-landings">

    <?php
        $options = get_option('illiant_landings');
        $figmaId = isset($options['figmaId']) ? sanitize_text_field(wp_unslash($options['figmaId'])) : '';
        $figmaKey = isset($options['figma']) ? sanitize_text_field(wp_unslash($options['figma'])) : '';
    ?>
    <?php
        $optionsLp = get_option('illiant_landings_lp');
        $requests = isset($optionsLp['requests']) ? sanitize_text_field(wp_unslash($optionsLp['requests'])) : 0;
    ?>
   <div class="headline-wrapper">
        
        <span class="requests-counter">الخطة الحالية: <strong class="current-plan"><?php echo esc_attr($planName); ?></strong> 
        | رصيد الائتمان المتبقي: <strong class="cnt-requests-be"></strong> | تجدد في: <strong class="cnt-renew-be"></strong></span>

       
        <h1>
            <img src="<?php echo plugins_url('/assets/images/FG3WP.png', dirname(__FILE__)); ?>" alt="FG3WP" width="140">| 
            <?php echo esc_html__('تحويل تصميم Figma', 'illiant-landings'); ?></h1>    
        
    </div> 
    <?php settings_errors(); ?>

    <?php if ( !fg3_fs()->can_use_premium_code()) : ?>
        <div id="notice-free-trial" class="notice notice-info is-dismissible">
            <p>
                <?php echo esc_html__('قم بترقية حسابك اليوم واحصل على أرصدة إضافية.', 'illiant-landings'); ?>
                <a href="#" class="button button-primary mx-2">
                    <?php echo esc_html__('ترقية حسابك!', 'illiant-landings'); ?>
                </a>
            </p>
        </div>
    <?php endif; ?>

    <?php include 'components/notification.php'; ?>

    <?php include 'components/modal.php'; ?>

    <?php include 'components/loader.php'; ?>
    

    <?php include 'components/alert.php'; ?>
    <div class="lp-box blue lp-settings-form">
        <form id="lp-options" class="horizontal-table" method="post" action="options.php">
            <?php 
                settings_fields('illiant_landings_lp_settings');
                do_settings_sections('illiant_wplandings_create');
            ?>
        </form>
    </div>
    <?php include 'components/loaderModule.php'; ?>
    <div class="lp-box lp-import-form">
        <h2><?php echo esc_html__('يرجى إدخال عنوان URL لتصميم Figma الذي ترغب في تحويله', 'illiant-landings'); ?></h2>
        <p><?php echo esc_html__('يجب أن تكتمل العملية خلال دقيقة إلى دقيقتين', 'illiant-landings'); ?>
        <div class="hidden">
            <input type="text" id="figma_access_token" name="figma_access_token" class="regular-text" value="<?php echo esc_attr($figmaKey); ?>">
        </div>
        <div class="hidden">
            <input type="text" id="figma_id" name="figma_id" class="regular-text" value="<?php echo esc_attr($figmaId); ?>">
        </div>
        
        <div class="hidden">
            <input type="text" id="planName" name="planName" class="regular-text" value="<?php echo esc_attr($planName);?>">
        </div>
        <div class="hidden">
            <input type="text" id="licenseId" name="licenseId" class="regular-text" value="<?php echo esc_attr($licenseId);?>">
        </div>
        <div class="hidden">
            <input type="text" id="created" name="created" class="regular-text" value="<?php echo esc_attr($created);?>">
        </div>
        <div class="hidden">
            <input type="text" id="expiration" name="expiration" class="regular-text" value="<?php echo esc_attr($expiration);?>">
        </div>
        <div class="hidden">
            <input type="text" id="landing_bg" name="landing_bg" class="regular-text" value="">
        </div>
        <form id="figma-desktop-form">
            <div class="row">
                <div class="col-md-6">
                    <label for="figma_desktop_url"><?php echo esc_html__('عنوان URL لتصميم Figma', 'illiant-landings'); ?></label>
                    <input type="text" id="figma_desktop_url" name="figma_desktop_url" class="regular-text" placeholder="<?php echo esc_html__('الصق عنوان URL لـ Figma هنا', 'illiant-landings'); ?>">
                    <span class="figma-error"><?php echo esc_html__('قم بإعداد مفاتيحك لاستيراد تصميم Figma', 'illiant-landings'); ?></span>
                </div>
                <div class="col-md-3">
                    <label for="figma_desktop_url"><?php echo esc_html__('نشر التصميم كـ:', 'illiant-landings'); ?></label>
                    <label class="label-radio">
                    <input type="radio" id="publishType" name="publishType" value="page" checked> صفحة
                    </label>
                    <label class="label-radio">
                    <input type="radio" id="publishType" name="publishType" value="post"> منشور
                    </label>
                </div>
                <div class="col-md-3">
                    <input type="submit" class="lp-btn blue large mt-4" value="<?php echo esc_html__('تحويل تصميم Figma', 'illiant-landings'); ?>">

                </div>
            </div>
        </form>
    </div>

    <div class="lp-box hidden">
        <div class="lp-preview-wrapper">
            <iframe id="lp-preview" class="desktop" src="" frameborder="0"></iframe>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="lp-box">
                <h2 class="mb-3  pt-2 text-center">اتصل  بنا  لِنُساعدك  في  إعداد  أول  تصميم  Figma  لِلتحويل  وِاحصل  على  20  ائتمانًا  مجانيًا  إضافيًا.  </h2>
                <div class="row">
                    <div class="col-md-6 offset-md-3">
                        <a class="lp-btn orange block" href="?page=illiant_wplandings-contact">اتصل  بِالدعم  الفني</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="lp-box">
                <h2 class="mb-3  pt-2 text-center">دليل  إعداد  التصميم</h2>
                <a class="lp-btn orange block" id="open_instruction">عرض  التعليمات</a>
            </div>
        </div>
        <div class="col-md-8">
            <div class="lp-box">
                <div class="video-guide text-center pt-2">
                    <h2 class="mb-3">تعلم  Figma  Auto layout  في  10  دقائق</h2>
                    <iframe width="560" height="315"  src="#" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>