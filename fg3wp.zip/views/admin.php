<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

$plan = fg3_fs()->get_plan();

$planName = "مجاني"; 

// Check if plan exists and assign plan name
if ($plan !== null && is_object($plan) && isset($plan->name)) {
    $planName = $plan->name;
}

?>

<div class="wrap illiant-settings wp-landings">
	<?php
        $options = get_option('illiant_landings');
        $figmaKey = isset($options['figma']) ? $options['figma'] : '';
    ?>
    <?php
        $optionsLp = get_option('illiant_landings_lp');
        $requests = isset($optionsLp['requests']) ? $optionsLp['requests'] : 0;
    ?>
    <div class="headline-wrapper">

		<h1><img src="<?php echo plugins_url('/assets/images/FG3WP.png', dirname(__FILE__)); ?>" alt="FG3WP" width="140"></h1>
        
    </div> 
	<?php settings_errors(); ?>


    <?php include 'components/alert.php'; ?>

	<div class="lp-box blue lp-settings-form">
		<form id="lp-settings" class="horizontal-table" method="post" action="options.php">
			<?php 
				settings_fields( 'illiant_landings_settings' );
				do_settings_sections( 'illiant_wplandings' );
			?>
		</form>
		<div class="mt-4">
			<button id="save-lp-settings" class="lp-btn orange large">حفظ</button>
		</div>
        <?php include 'components/loaderModule.php'; ?>

	</div>
    <div class="lp-box lp-docs">
        <div class="row">
            <div class="col-md-12">
                <h2>الحصول  على  رمز  وصول  Figma</h2>
                <p>رمز  وصول  Figma  هو  عبارة  عن  "كلمة  سرّ"  آمنة  تُمكّن  البرامج  من  الوصول  إلى  تصاميمك  وِبياناتك  في  Figma. <br><br>

للحصول  على  رمزك:</p>
                <p>1. افتح  تطبيق  Figma  على  سطح  المكتب  أو  موقع  الإنترنت  وِادخل  إلى  إعدادات  حسابك.  ابحث  عن  قسم  <strong>رموز  الوصول  الشخصية</strong>.</p>
                <img src="<?php echo plugins_url('/assets/images/figma-settings.png', dirname(__FILE__)); ?>" width="200">
                <p>2.  اختر  <strong>إنشاء  رمز  جديد</strong>،  وِأعطِه  اسمًا،  وِانسخ  الرمز.  يُمكن  هذا  WPLandings  من  استيراد  تصاميمك  في  Figma.  </p>
                <img src="<?php echo plugins_url('/assets/images/figma-token.png', dirname(__FILE__)); ?>" width="400">
                <p>3.  تأكد  من  أن  حساب  Figma  الذي  يحتوي  على  رمز  الوصول  له  أذونات  العرض  أو  التحرير  للِملف،  وِخاصة  إذا  كان  الِملف  خاصًا.</p>
                <h2>هل  تحتاج  إلى  المساعدة؟</h2>
                <p>سواء  كنت  تُنشئ  مُفتاح  API  لِـ  OpenAI  أو  رمز  وصول  Figma،  فَنحن  هنا  لِدعمك.  لِلحصول  على  المساعدة،  ما  عليك  إلّا  ملء  نموذج  <a href="https://illiant.ai/contact-us/" target="_blank">الدعم</a>.</p>
                <h2>الأسئلة  الشائعة</h2>
                <p>هل  لديك  أسئلة  حول  دمج  OpenAI  و  Figma  أو  كيفية  الاستفادة  القصوى  من  WPLandings؟  قسم  <a href="admin.php?page=illiant_wplandings_faq">الأسئلة  الشائعة</a>  جاهز  لِتوفير  البِصائر  التي  تحتاج  إليها.  </p>
            </div>
        </div>
        
    </div>
</div>