<?php 
/**
 * @package  illiantLandings
 */
namespace Illiantland\Pages;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use Illiantland\Api\SettingsApi;
use Illiantland\Base\BaseController;
use Illiantland\Api\Callbacks\AdminCallbacks;
use Illiantland\Api\Callbacks\SettingsCallbacks;

/**
* 
*/
class Settings extends BaseController
{
	/**
	 * Instance of SettingsApi to manage plugin settings.
	 * @var SettingsApi
	 */
	public $settings;

	/**
	 * Instance of AdminCallbacks for handling admin callbacks.
	 * @var AdminCallbacks
	 */
	public $callbacks;

	/**
	 * Instance of SettingsCallbacks for handling settings callbacks.
	 * @var SettingsCallbacks
	 */
	public $callbacks_settings;

	/**
	 * Array of pages to be added to the admin menu.
	 * @var array
	 */
	public $pages = array();

	/**
	 * Register all necessary hooks and settings for the plugin's admin page.
	 */
	public function register() 
	{
		$this->settings = new SettingsApi();

		$this->callbacks = new AdminCallbacks();

		$this->callbacks_settings = new SettingsCallbacks();

		$this->setPages();
		$this->setSettings();
		$this->setSections();
		$this->setFields();

		$this->settings->addPages( $this->pages )->withSubPage( 'Settings' )->register();
	}

	/**
	 * Initializes the plugin's admin page settings.
	 * This method sets up the configuration for the main plugin page in the WordPress admin menu,
	 * including the page title, menu title, required capability for access, menu slug, and the callback
	 * for rendering the page view. An icon URL and position in the menu are also specified.
	 */
	public function setPages() 
	{
	$this->pages = array(
    array(
        'page_title' => 'FG3WP', 
        'menu_title' => 'WPLandings', 
        'capability' => 'manage_options', 
        'menu_slug' => 'illiant_wplandings', 
        'callback' => array( $this->callbacks, 'adminSettings' ), 
        'icon_url' => 'https://tast.araborbit.com/wp-content/uploads/2024/09/FG3WP-4.png',
        'position' => 6
    )
);

	}

	/**
	 * Configures the plugin's settings.
	 * This method prepares the settings array for registration, specifying the option group,
	 * option name, and the callback function for sanitization of the settings' values. These
	 * settings are then registered using the SettingsApi.
	 */
	public function setSettings()
	{
		$args = array(
			array( 
				'option_group' => 'illiant_landings_settings',
				'option_name' => 'illiant_landings',
				'callback' => array( $this->callbacks_settings, 'keysSanitize' )
			)
		);

        $this->settings->setSettings( $args );
	}

	/**
 	* Sets up the sections for the plugin's settings page.
	* This method defines the sections that will be displayed on the plugin's settings page,
	* including their IDs, titles, callback functions for rendering the section descriptions,
	* and the page on which they should appear. These sections help organize settings logically.
	*/
	public function setSections()
	{
		$args = array(
			array(
				'id' => 'illiant_admin_index',
				'title' => 'Set-up your keys',
				'callback' => array( $this->callbacks_settings, 'settingsManager' ),
				'page' => 'illiant_wplandings'
			)
		);

		$this->settings->setSections( $args );
	}

	/**
	 * Initializes the fields for the plugin's settings sections.
	 * This method configures each setting field, including its ID, title, callback for rendering
	 * the field, the page and section it belongs to, and additional arguments such as the label
	 * for the field and any CSS classes. These fields allow users to input or adjust settings values.
	 */
	public function setFields()
	{
		$args = array(
			array(
                'id' => 'illiant_figma',
                'title' => 'Figma Token',
                'callback' => array($this->callbacks_settings, 'figmaKeyField'),
                'page' => 'illiant_wplandings',
                'section' => 'illiant_admin_index',
				'args' => array(
                    'label_for' => 'illiant_figma',
					'class' => 'lp-key',
				)
			),
			array(
                'id' => 'illiant_figma_id',
                'title' => 'Figma Id',
                'callback' => array($this->callbacks_settings, 'figmaIdField'),
                'page' => 'illiant_wplandings',
                'section' => 'illiant_admin_index',
				'args' => array(
                    'label_for' => 'illiant_figma_id',
					'class' => 'hidden',
				)
			)
        );
        $this->settings->setFields($args);
	}
}