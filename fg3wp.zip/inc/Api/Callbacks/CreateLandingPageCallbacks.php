<?php 
/**
 * Provides callback functionalities for creating landing pages.
 *
 * This class handles the rendering of the settings fields and sanitization of inputs for
 * the landing page creation.
 *
 * @package  illiantLandings
 */

namespace Illiantland\Api\Callbacks;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Class CreateLandingPageCallbacks
 *
 * Handles the creation and management of landing pages,
 * including rendering settings fields and sanitizing inputs.
 */
class CreateLandingPageCallbacks
{

    /**
     * Displays a message for the landing page section manager.
     */
    public function lpSectionManager()
    {
        echo '<p>' . esc_html__('These are the general settings of your landing page. You can modify them at any time in the edit view after publishing your landing page.', 'illiantlandings') . '</p>';    

    }

     /**
     * Sanitizes the inputs from the landing page creation form.
     *
     * @param array $input The input array from the form.
     * @return array The sanitized array.
     */
    public function lpSanitize($input) 
    {
        update_option('illiant_landings_permalink', '');

        if (isset($input['sections']) && is_array($input['sections'])) {
            foreach ($input['sections'] as &$section) {
                $section['html'] = isset($section['html']) ? wp_kses_post($section['html']) : '';
                $section['css'] = isset($section['css']) ? $this->sanitizeCSS($section['css']) : '';
            }
            unset($section); 
            $input['sections'] = wp_json_encode($input['sections']);
        }

        if (isset($_POST['create_lp'])) {
            $nonce_action = 'illiant_save_landing';
            $nonce = isset($_POST['illiant_save_landing_nonce']) ? sanitize_text_field(wp_unslash($_POST['illiant_save_landing_nonce'])) : '';

            if (!$nonce || !wp_verify_nonce($nonce, $nonce_action)) {
                wp_die(esc_html__('Nonce verification failed!', 'illiant-landings'));
            }

            if (!current_user_can('edit_pages')) {
                wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'illiant-landings'));
            }

            $publishType = isset($_POST['create_lp']) ? sanitize_text_field($_POST['create_lp']) : 'page'; // Default to 'page'

            $this->createLandingPage($input, $publishType);
        }
        

        return $input;
    }

    /**
     * Sanitizes CSS content.
     *
     * This method should remove potentially harmful parts of CSS content
     * without encoding characters unnecessarily.
     *
     * @param string $css The CSS content to sanitize.
     * @return string Sanitized CSS.
     */
    protected function sanitizeCSS($css) {
        $css = str_replace(['<script>', '</script>', 'expression', 'javascript:', 'vbscript:', 'data:text/html'], '', $css);
        return $css;
    }

    /**
     * Handles the creation of a new landing page.
     *
     * @param array $input The sanitized input from the landing page form.
     * @return array An array with the operation outcome.
     */
    public function createLandingPage($input, $publishType = 'page')
    {   
        if (!current_user_can('edit_pages')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $output = array(); 
        $title = isset($input['title']) ? sanitize_text_field(wp_unslash($input['title'])) : 'No title';
        //$sections = isset($input['sections']) ? json_decode($input['sections'], true) : [];
        $blocks = isset($input['landing_blocks']) ? wp_unslash($input['landing_blocks']) : 'Something went wrong';
        error_log('Value of $publishType: ' . print_r($publishType, true));
        $post_id = wp_insert_post(array(
            'post_title' => $title,
            'post_content' => $blocks,
            'post_status' => 'draft',
            'post_type' => $publishType,
        ));

        if (!is_wp_error($post_id)) {
            // Generate the link to the editor
            $editor_link = admin_url('post.php?post=' . $post_id . '&action=edit');
            
            if (!$editor_link) {
                $editor_link = '';
            }
            // Save the editor link instead of the permalink
            update_option('illiant_landings_permalink', $editor_link);

        } else {
            return new WP_Error('post_creation_failed', esc_html__('Landing page creation failed.', 'illiant-landings'));
        }
        return $output;

    }

    /**
     * Renders a JSON field for the landing page configuration.
     */
    public function lpJSONField()
    {
        $options = get_option('illiant_landings_lp');
        $sections = isset($options['sections']) ? json_decode($options['sections'], true) : [];
        $htmlContent = '';
        $cssContent = '';
        wp_nonce_field('illiant_save_landing', 'illiant_save_landing_nonce');
        if (is_array($sections)) {
            foreach ($sections as $section) {
                $htmlContent .= isset($section['html']) ? wp_kses_post($section['html']) : '';
                $cssContent .= isset($section['css']) ? $this->sanitizeCSS($section['css']) : '';
            }
        }
 
        $sections_json = !empty($sections) ? wp_json_encode($sections) : '';
        echo '<textarea name="illiant_landings_lp[sections]" id="sectionsJSON" rows="10" cols="50">' . esc_textarea($sections_json) . '</textarea>';
    }

    /**
     * Renders a text field for landing page settings.
     *
     * @param array $args Arguments for rendering the text field.
     */
    public function textField($args)
    {   
        $options = get_option('illiant_landings_lp');
        $name = isset($args['label_for']) ? $args['label_for'] : '';
        $value = isset($options[$name]) ? $options[$name] : '';
        $class = isset($args['class']) ? $args['class'] : '';

        echo '<input type="text" name="illiant_landings_lp[' . esc_attr($name) . ']" id="' . esc_attr($name) . '" class="' . esc_attr($class) . '" value="' . esc_attr($value) . '">';
    }

}
