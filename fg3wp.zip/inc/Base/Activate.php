<?php
/**
 * @package  illiantLandings
 */
namespace Illiantland\Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Activate
{
	/**
	 * Handles tasks to run during plugin activation.
	 * This includes registering custom post types, flushing rewrite rules to ensure
	 * custom post type permalinks work correctly, and setting default plugin options
	 * if they do not already exist.
	 */
	public static function activate() {

		flush_rewrite_rules();

		$default = array();
		$permalink ='';

		if ( ! get_option( 'illiant_landings' ) ) {
			update_option( 'illiant_landings', $default );
		}

		if ( ! get_option( 'illiant_landings_lp' ) ) {
			update_option( 'illiant_landings_lp', $default );
		}

		if ( ! get_option( 'illiant_landings_permalink' ) ) {
			update_option( 'illiant_landings_permalink', $permalink );
		}
	
	}
}