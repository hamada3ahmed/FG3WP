<?php 
/**
 * @package  illiantLandings
 */

namespace Illiantland\Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use Illiantland\Api\SettingsApi;
use Illiantland\Base\BaseController;
use Illiantland\Api\Callbacks\AdminCallbacks;
use Illiantland\Api\Callbacks\CreateLandingPageCallbacks;

/**
 * Class CreateLandingPageController
 *
 * 
 * This class is responsible for setting up the landing page creation form,
 * saving the settings, and handling the rendering of the landing page.
 */

class CreateLandingPageController extends BaseController
{
    /**
     * Settings API
     * 
     * @var SettingsApi
     */
    public $settings;

    /**
     * Holds subpages information
     * 
     * @var array
     */
    public $subpages = array();

    /**
     * Holds the callbacks for admin area
     * 
     * @var AdminCallbacks
     */
    public $callbacks;

    /**
     * Holds the callbacks for landing page creation
     * 
     * @var CreateLandingPageCallbacks
     */
    public $callbacks_lp;

    /**
     * Registers settings, sections, fields, and AJAX actions for landing page functionality.
     * Sets up necessary hooks and configurations for creating and managing landing pages.
     */
    public function register()
    {
        $this->settings = new SettingsApi();

        $this->callbacks = new AdminCallbacks();

        $this->callbacks_lp = new CreateLandingPageCallbacks();

        $this->setSubpages();

        $this->setSettings();

        $this->setSections();

        $this->setFields();

        $this->settings->addSubPages( $this->subpages )->register();

        add_action('wp_ajax_your_action', 'handle_figma_request');
        add_action('wp_ajax_nopriv_your_action', 'handle_figma_request');
        add_action('wp_ajax_upload_figma_images', array($this, 'handle_figma_image_upload'));



    }      
    
    /**
     * Handles the AJAX request for Figma data.
     * This method is designed to respond to a specific AJAX action called 'your_action'.
     */
    function handle_figma_request() 
    {
        wp_send_json();
        wp_die(); 
    }

    /**
     * Downloads an image from a given URL to the server.
     * 
     * @param string $imageUrl The URL of the image to download.
     * @return string|false The file path to the downloaded image on success, false on failure.
     */
    private function download_image_to_server($imageUrl) 
    {
        $response = wp_remote_get($imageUrl);

        if (is_wp_error($response)) {
            return false; 
        }

        $imageData = wp_remote_retrieve_body($response);

        if (!$imageData) {
            return false;
        }

        global $wp_filesystem;
        require_once ( ABSPATH . '/wp-admin/includes/file.php' );
        WP_Filesystem();

        $tmpFilePath = tempnam(sys_get_temp_dir(), 'FIG');
        if ($wp_filesystem->put_contents($tmpFilePath, $imageData)) {
            return $tmpFilePath;
        }

        return false;
    }

    /**
     * Handles the uploading of images from Figma to WordPress.
     * This method is invoked via AJAX to upload images and associate them with a section ID.
     */
    public function handle_figma_image_upload() {

        // Initialize response variables
        $uploadedImageUrls = [];
        $debugMessages = [];
        $errorOccurred = false;

        // Security check: Ensure the user has the capability to upload files
        if (!current_user_can('upload_files')) {
            wp_send_json_error(__('Unauthorized: You do not have permission to upload files.', 'illiant-landings'));
            wp_die();
        }

        // Security check: Ensure nonce sent with AJAX request
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!$nonce || !wp_verify_nonce($nonce, 'figmaupload_nonce')) {
            wp_send_json_error(__('Nonce verification failed', 'illiant-landings'));
            wp_die();
        }

        // Validate the images data structure
        if (!isset($_POST['images'])) {
            $debugMessages[] = esc_html__('No images provided or invalid structure.', 'illiant-landings');
            wp_send_json_error(['debugMessages' => $debugMessages]);
            return;
        }
    
        // Sanitize the section ID
        $sectionId = isset($_POST['sectionId']) ? sanitize_text_field(wp_unslash($_POST['sectionId'])) : '';
    
        // Sanitize and validate each image's data
        $imagesData = array_map(function($image) {
            $sanitizedImageUrl = isset($image['imageUrl']) ? sanitize_url(wp_unslash($image['imageUrl'])) : '';
            $sanitizedDescription = isset($image['imageDescription']) ? sanitize_text_field(wp_unslash($image['imageDescription'])) : '';
            $sanitizedNodeId = isset($image['nodeId']) ? sanitize_text_field(wp_unslash($image['nodeId'])) : '';
            return [
                'imageUrl' => $sanitizedImageUrl,
                'imageDescription' => $sanitizedDescription,
                'nodeId' => $sanitizedNodeId
            ];
        }, $_POST['images']);
    
        // Include necessary WordPress files for handling media uploads
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
    
        // Process each image
        foreach ($imagesData as $image) {
            // Validate the image URL
            $imageUrl = isset($image['imageUrl']) ? sanitize_url(wp_unslash($image['imageUrl'])) : '';

            if (!filter_var($imageUrl, FILTER_VALIDATE_URL)) {
                $debugMessages[] = esc_html__('Invalid image URL: ', 'illiant-landings') . esc_url($imageUrl);
                continue;
            }
            // Download the image to the server
            $tmpFilePath = $this->download_image_to_server($imageUrl);
            if (!$tmpFilePath) {
                $debugMessages[] = esc_html__('Failed to download image:', 'illiant-landings') . esc_url($imageUrl);
                continue;
            }
    
            // Determine the file's MIME type and corresponding extension
            $mimeType = mime_content_type($tmpFilePath);
            $extension = '';
            switch ($mimeType) {
                case 'image/jpeg':
                    $extension = '.jpg';
                    break;
                case 'image/png':
                    $extension = '.png';
                    break;
                // Add more MIME types and extensions if needed
            }

            global $wp_filesystem;

            

            // Ensure the file has a recognized extension before proceeding
            if ($extension) {
                $newFilePath = $tmpFilePath . $extension;
                if ($wp_filesystem->move($tmpFilePath, $newFilePath, true)) {
                    $tmpFilePath = $newFilePath; 
                }
            } else {
                $debugMessages[] = esc_html__('Unrecognized image MIME type: ', 'illiant-landings') . $mimeType;
                wp_delete_file($tmpFilePath);
                continue;
            }
            
            $nodeId = isset($image['nodeId']) ? sanitize_text_field(wp_unslash($image['nodeId'])) : '';
            // Prepare the file array for sideloading
            $file = [
                'name' => $sectionId . '-' . $nodeId . $extension,
                'type' => $mimeType, 
                'tmp_name' => $tmpFilePath,
                'error' => 0,
                'size' => filesize($tmpFilePath),
            ];
    
            // Attempt to sideload the file into the WordPress Media Library
            $sideloaded = media_handle_sideload($file, 0);
            if (is_wp_error($sideloaded)) {
                $errorOccurred = true;
                $debugMessages[] = esc_html__('Error sideloading image: ', 'illiant-landings') . $sideloaded->get_error_message();
                wp_delete_file($tmpFilePath);
                continue; // Continue processing the next image
            }
    
            // Get the URL of the uploaded image and add it to the response
            $uploadedImageUrl = wp_get_attachment_url($sideloaded);
            $uploadedImageUrls[] = [
                'url' => $uploadedImageUrl,
                'description' => isset($image['imageDescription']) ? sanitize_text_field(wp_unslash($image['imageDescription'])) : ''
            ];
            $debugMessages[] = esc_html__('Image uploaded:', 'illiant-landings')  . $uploadedImageUrl;
    
            // Delete the temporary file
            wp_delete_file($tmpFilePath);
        }
    
        // Log debug messages
        error_log(print_r($debugMessages, true));
    
        // Send the response
        if ($errorOccurred) {
            wp_send_json_error(['debugMessages' => $debugMessages]);
        } else {
            wp_send_json_success(['uploadedImageUrls' => $uploadedImageUrls, 'debugMessages' => $debugMessages]);
        }
    }
    
    
    /**
     * Defines the subpages to be added under the main plugin menu.
     */
    private function setSubpages()
    {
        $this->subpages = array(
            array(
                'parent_slug' => 'illiant_wplandings', 
                'page_title' => 'Convert Figma design', 
                'menu_title' => 'Convert Figma design', 
                'capability' => 'manage_options', 
                'menu_slug' => 'illiant_wplandings_create', 
                'callback' => array( $this->callbacks, 'adminCreateLanding' )
            )
        );
    }

    /**
     * Registers the settings for the landing page functionality in the plugin.
     */
    private function setSettings()
    {
        $args = array(
            array(
                'option_group' => 'illiant_landings_lp_settings',
                'option_name' => 'illiant_landings_lp',
                'callback' => array( $this->callbacks_lp, 'lpSanitize' )
            )
        );
        
        $this->settings->setSettings( $args );
    }

    /**
     * Registers sections for the landing page settings in the admin area.
     */
    private function setSections()
    {
        $args = array(
            array(
                'id' => 'illiant_lp_index',
                'title' => 'Landing page settings',
                'callback' => array( $this->callbacks_lp, 'lpSectionManager' ),
                'page' => 'illiant_wplandings_create'
            )
        );
        $this->settings->setSections($args);
        
    }

    /**
     * Registers the fields for landing page functionality, allowing user inputs for various settings.
     */
    public function setFields()
    {
        $header_options = $this->getHeaderOptions();
        $footer_options = $this->getFooterOptions();

        $args = array(
            array(
                'id' => 'illiant_lp_content',
                'title' => 'Landing Page content',
                'callback' => array($this->callbacks_lp, 'lpJSONField'),
                'page' => 'illiant_wplandings_create',
                'section' => 'illiant_lp_index',
                'args' => array(
					'class' => 'hidden',
				)
			),
            array(
                'id' => 'illiant_lp_blocks',
                'title' => 'Landing Page blocks',
                'callback' => array($this->callbacks_lp, 'textField'),
                'page' => 'illiant_wplandings_create',
                'section' => 'illiant_lp_index',
                'args' => array(
                    'label_for' => 'landing_blocks',
					'class' => 'hidden',
				)
			),
            array(
                'id' => 'illiant_lp_desktop_figma',
                'title' => 'Desktop figma',
                'callback' => array($this->callbacks_lp, 'textField'),
                'page' => 'illiant_wplandings_create',
                'section' => 'illiant_lp_index',
                'args' => array(
                    'label_for' => 'desktop_figma_url',
                    'class' => 'hidden',
                )
			),
            array(
                'id' => 'illiant_lp_requests',
                'title' => 'API requests',
                'callback' => array($this->callbacks_lp, 'textField'),
                'page' => 'illiant_wplandings_create',
                'section' => 'illiant_lp_index',
                'args' => array(
                    'label_for' => 'requests',
                    'class' => 'hidden',
                )
			),
            array(
                'id' => 'illiant_lp_title',
                'title' => 'Landing Page title',
                'callback' => array($this->callbacks_lp, 'textField'),
                'page' => 'illiant_wplandings_create',
                'section' => 'illiant_lp_index',
                'args' => array(
                    'label_for' => 'title',
					'class' => 'lp-title',
				)
			)
        );
        $this->settings->setFields($args);
    }
}